<?php

namespace App\Controllers\Transaksi;

use App\Controllers\BaseController;
use App\Helpers\QueryTransaksi;
use stdClass;

class BarangKeluar extends BaseController
{
    protected $query;
    protected $db;

    public function __construct()
    {
        $this->query = new QueryTransaksi();
        $this->db = \Config\Database::connect();
    }

    public function index()
    {
        $tglawal = date('Y-m-d');
        $tglakhir = date('Y-m-d');

        $data = [
            'title' => 'Data Barang Keluar',
            'filter_tglawal' => $tglawal,
            'filter_tglakhir' => $tglakhir,
        ];
        return view('barang_keluar/viewBarangKeluar', $data);
    }

    public function loadDataBarangKeluar()
    {
        $tglawal = $this->request->getVar('tglawal');
        if (empty($tglawal)) {
            $tglawal = date('Y-m-d');
        }
        $tglawal = date('Y-m-d', strtotime($tglawal));

        $tglakhir = $this->request->getVar('tglakhir');
        if (empty($tglakhir)) {
            $tglakhir = date('Y-m-d');
        }
        $tglakhir = date('Y-m-d', strtotime($tglakhir));

        $data = [
            'result' => $this->query->getBarangKeluar($tglawal, $tglakhir)->getResultArray(),
            'filter_tglawal' => $tglawal,
            'filter_tglakhir' => $tglakhir,
        ];
        return view('barang_keluar/dataBarangKeluar', $data);
    }

    public function createBarangKeluar()
    {
        $data = [
            'bahan' => $this->query->getBahan()->getResultArray(),
            'parameter' => $this->query->getParameterUji()->getResultArray(),
        ];
        return view('barang_keluar/createBarangKeluar', $data);
    }

    public function loadDataBahan()
    {
        $data = $this->query->getBahan()->getResultArray();
        $data2 = $this->query->getParameterUji()->getResultArray();
        $datalengkap = array(
            'data_bahan' => $data,
            'data_parameter' => $data2,
        );

        echo json_encode($datalengkap);
    }

    public function loadDetailBahan()
    {
        $id_bahan = $this->request->getVar('id_bahan');
        if ($id_bahan) {
            $data = $this->query->getBahanSatuan($id_bahan)->getRowArray();
            echo json_encode($data);
        }
    }

    public function saveBarangKeluar()
    {
        $row_bahan = $this->request->getVar('jumlah');
        $tanggal = $this->request->getVar('tanggal');
        $time = date('H:i:s');

        $data = new stdClass();
        $data->datetime = date('Y-m-d', strtotime($tanggal)) . " " . $time;

        $this->db->transBegin();

        foreach (array_filter($row_bahan) as $key => $value) {
            $data->bahan = $this->request->getVar('bahan')[$key];
            $jumlah = $this->request->getVar('jumlah')[$key];
            if (strpos($jumlah, ',') == TRUE) {
                $data->jumlah = str_replace(',', '.', $jumlah);
            } else {
                $data->jumlah = $jumlah;
            }
            // $data->keterangan = $this->request->getVar('keterangan')[$key];
            $data->parameter = $this->request->getVar('parameter')[$key];

            // $data_stok = $this->query->getStokAkhirTstok($data->bahan)->getRowArray();
            $sum_stok = $this->query->getStokAkhir($data->bahan)->getRowArray();
            $data_stok = $this->query->getStokAkhirFromMaster($data->bahan)->getRowArray();
            if ($data_stok['stok_akhir'] > 0) {
                $total_stok = $data_stok['stok_akhir'];
            } else {
                $total_stok = $data_stok['stok_awal'];
            }
            // if ($data_stok) {
            //     $stok_akhir = $data_stok['stok_akhir'] - $data->jumlah;
            // } else {
            //     $data_stok = $this->query->getStokAkhirFromMaster($data->bahan)->getRowArray();
            //     $stok_akhir = $data_stok['stok_akhir'] - $data->jumlah;
            // }
            // $sisa_stok = $stok_akhir - $data->jumlah;
            // $tgl_bulan = date('n', strtotime($tanggal));
            // $tgl_tahun = date('Y', strtotime($tanggal));

            $sisa_stok = ($sum_stok['total_masuk'] * $data_stok['gramasi']) - $sum_stok['total_keluar'];
            if (($total_stok + $sisa_stok) > $data->jumlah) {
                $proses[] = $this->query->saveBarangKeluar($data);
            } else {
                $proses[] = false;
            }
            // if ($sisa_stok) {
            //     $this->query->updateStok($data->bahan, $tgl_tahun, $tgl_bulan, $sisa_stok);
            // } else {
            //     if ($data_stok['tahun'] == $tgl_tahun and $data_stok['bulan'] == $tgl_bulan) {
            //         $this->query->saveStok($data->bahan, $tgl_tahun, $tgl_bulan, $sisa_stok);
            //     } else {
            //         $this->query->saveStok($data->bahan, $tgl_tahun, $tgl_bulan, $sisa_stok);
            //     }
            // }
        }

        if (in_array(false, $proses)) {
            $this->db->transRollback();
            $response = [
                'status' => 500,
                'message' => 'Data Gagal Disimpan, Jumlah Barang Keluar Melebihi Stok',
                'error' => true
            ];
        } else {
            $this->db->transCommit();
            $response = [
                'status' => 200,
                'message' => 'Data Berhasil Disimpan',
                'error' => false
            ];
        }
        return json_encode($response);
    }

    public function deleteBarangKeluar($id)
    {
        $data_barangkeluar = $this->query->getBarangKeluarById($id)->getRowArray();
        // $data_stok = $this->query->getStokAkhir($data_barangkeluar['m_inventori_bahan_lab'])->getRowArray();
        // $data_stok = $this->query->getStokAkhirTstok($data_barangkeluar['m_inventori_bahan_lab'])->getRowArray();
        // if ($data_stok) {
        //     $stok_akhir = $data_stok['stok_akhir'] - $data_barangkeluar['jumlah'];
        // } else {
        //     $data_stok = $this->query->getStokAkhirFromMaster($data_barangkeluar['m_inventori_bahan_lab'])->getRowArray();
        //     $stok_akhir = $data_stok['stok_akhir'] - $data_barangkeluar['jumlah'];
        // }
        // $sisa_stok = $stok_akhir - $data_barangkeluar['jumlah'];

        $this->db->transBegin();

        $this->query->deleteBarangKeluar($id);
        // $this->query->updateStokDelete($data_barangkeluar['m_inventori_bahan_lab'], $sisa_stok);

        if ($this->db->transStatus() === false) {
            $this->db->transRollback();
            $response = [
                'status' => 500,
                'message' => 'Data Gagal Dihapus',
                'error' => true
            ];
        } else {
            $this->db->transCommit();
            $response = [
                'status' => 200,
                'message' => 'Data Berhasil Dihapus',
                'error' => false
            ];
        }
        return json_encode($response);
    }
}
