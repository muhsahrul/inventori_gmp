<?php

namespace App\Controllers;

use App\Helpers\QueryMaster;

class Login extends BaseController
{
    public function index()
    {
        $data = [
            'validation' => \Config\Services::validation()
        ];
        return view('auth/login', $data);
    }

    public function auth()
    {
        if (!$this->validate([
            'email' => 'required|max_length[100]',
            'password' => 'required|max_length[255]'
        ])) {
            $validation = \Config\Services::validation();
            return redirect()->back()->withInput()->with('validation', $validation);
        }
        $query = new QueryMaster();
        $email = $this->request->getVar('email');
        $password = $this->request->getVar('password');
        $data = $query->getLogin($email)->getRowArray();
        if ($data) {
            $pass = $data['password'];
            if (md5($password) === $pass) {
                $ses_data = [
                    'user_id'   => $data['id'],
                    'user_name' => $data['nama'],
                    'logged_in' => TRUE
                ];
                session()->set($ses_data);
                return redirect()->to('/');
            } else {
                session()->setFlashdata('msg', 'Password Salah.');
                return redirect()->back()->withInput();
            }
        } else {
            session()->setFlashdata('msg', 'Data User Tidak Ada.');
            return redirect()->back()->withInput();
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
