<?php

namespace App\Controllers\Report;

use App\Controllers\BaseController;
use App\Helpers\QueryReport;

class ReportStok extends BaseController
{
    protected $query;

    public function __construct()
    {
        $this->query = new QueryReport();
    }

    public function index()
    {
        $tglawal = date('Y-m-d');
        $tglakhir = date('Y-m-d');

        $data = [
            'title' => 'Data Report Stok Bahan',
            'filter_stokawal' => $this->query->getMinTglStokAwal()->getRowArray(),
            'filter_tglawal' => $tglawal,
            'filter_tglakhir' => $tglakhir,
        ];
        return view('report/viewReportStok', $data);
    }

    public function loadDataReportStok()
    {
        $tglawal = $this->request->getVar('tglawal');
        if (empty($tglawal)) {
            $tglawal = date('Y-m-d');
        }
        $tglawal = date('Y-m-d', strtotime($tglawal));

        $tglakhir = $this->request->getVar('tglakhir');
        if (empty($tglakhir)) {
            $tglakhir = date('Y-m-d');
        }
        $tglakhir = date('Y-m-d', strtotime($tglakhir));

        $bahan = $this->query->getBahan()->getResultArray();
        foreach ($bahan as $key => $value) {
            if (empty($value['tgl_stok_awal'])) {
                $tgl_stok_awal = 0;
            } else {
                $tgl_stok_awal = $value['tgl_stok_awal'];
            }

            $total_masuk_keluar = $this->query->getTotalKeluarMasuk($value['id'], $tglawal)->getRowArray();
            if (strtotime($tgl_stok_awal) <= strtotime($tglawal)) {
                if (empty($value['stok_awal'])) {
                    $jumlah_stok_awal = 0;
                } else {
                    $jumlah_stok_awal = $value['stok_awal'];
                }

                $stok_awal = $jumlah_stok_awal + $total_masuk_keluar['total_masuk'] - $total_masuk_keluar['total_keluar'];
            } elseif (strtotime($tgl_stok_awal) > strtotime($tglawal)) {
                $stok_awal = $total_masuk_keluar['total_masuk'] - $total_masuk_keluar['total_keluar'];
            }

            $data_total_masuk = $this->query->getTotalMasuk($value['id'], $tglawal, $tglakhir)->getRowArray();
            $data_total_keluar = $this->query->getTotalKeluar($value['id'], $tglawal, $tglakhir)->getRowArray();
            $arr[] = [
                'id' => $value['id'],
                'kode' => $value['kode'],
                'nama' => $value['nama'],
                'stok_awal' => $stok_awal,
                'total_masuk' => $data_total_masuk['total_masuk'] * $value['gramasi'],
                'total_keluar' => (float)$data_total_keluar['total_keluar'],
                'stok_akhir' => $stok_awal + ($data_total_masuk['total_masuk'] * $value['gramasi']) - $data_total_keluar['total_keluar'],
            ];
        }

        $data = [
            'bahan' => $arr,
            'filter_tglawal' => $tglawal,
            'filter_tglakhir' => $tglakhir,
        ];
        return view('report/dataReportStok', $data);
    }

    public function exportReportStok()
    {
        $tglawal = $this->request->getVar('tglawal');
        if (empty($tglawal)) {
            $tglawal = date('Y-m-d');
        }
        $tglawal = date('Y-m-d', strtotime($tglawal));

        $tglakhir = $this->request->getVar('tglakhir');
        if (empty($tglakhir)) {
            $tglakhir = date('Y-m-d');
        }
        $tglakhir = date('Y-m-d', strtotime($tglakhir));

        $bahan = $this->query->getBahan()->getResultArray();
        foreach ($bahan as $key => $value) {
            if (empty($value['tgl_stok_awal'])) {
                $tgl_stok_awal = 0;
            } else {
                $tgl_stok_awal = $value['tgl_stok_awal'];
            }

            $total_masuk_keluar = $this->query->getTotalKeluarMasuk($value['id'], $tglawal)->getRowArray();
            if (strtotime($tgl_stok_awal) <= strtotime($tglawal)) {
                if (empty($value['stok_awal'])) {
                    $jumlah_stok_awal = 0;
                } else {
                    $jumlah_stok_awal = $value['stok_awal'];
                }

                $stok_awal = $jumlah_stok_awal + $total_masuk_keluar['total_masuk'] - $total_masuk_keluar['total_keluar'];
            } elseif (strtotime($tgl_stok_awal) > strtotime($tglawal)) {
                $stok_awal = $total_masuk_keluar['total_masuk'] - $total_masuk_keluar['total_keluar'];
            }

            $data_total_masuk = $this->query->getTotalMasuk($value['id'], $tglawal, $tglakhir)->getRowArray();
            $data_total_keluar = $this->query->getTotalKeluar($value['id'], $tglawal, $tglakhir)->getRowArray();
            $arr[] = [
                'id' => $value['id'],
                'kode' => $value['kode'],
                'nama' => $value['nama'],
                'stok_awal' => $stok_awal,
                'total_masuk' => $data_total_masuk['total_masuk'] * $value['gramasi'],
                'total_keluar' => (float)$data_total_keluar['total_keluar'],
                'stok_akhir' => $stok_awal + ($data_total_masuk['total_masuk'] * $value['gramasi']) - $data_total_keluar['total_keluar'],
            ];
        }

        $data = [
            'bahan' => $arr,
            'filter_tglawal' => $tglawal,
            'filter_tglakhir' => $tglakhir,
        ];
        return view('report/exportReportStok', $data);
    }
}
