<?php

namespace App\Controllers\Master;

use App\Controllers\BaseController;
use App\Helpers\QueryMaster;

class Katalog extends BaseController
{
    protected $query;

    public function __construct()
    {
        $this->query = new QueryMaster();
    }

    public function index()
    {
        $data = [
            'title' => 'Data Katalog',
        ];
        return view('katalog/viewKatalog', $data);
    }

    public function loadDataKatalog()
    {
        $data = [
            'result' => $this->query->getKatalog()->getResultArray(),
        ];
        return view('katalog/dataKatalog', $data);
    }

    public function createKatalog()
    {
        $data = [
            'bahan' => $this->query->getBahan()->getResultArray(),
        ];
        return view('katalog/createKatalog', $data);
    }

    public function saveKatalog()
    {
        $katalog = $this->request->getVar('katalog');
        $bahan = $this->request->getVar('bahan');

        $proses = $this->query->saveKatalog($katalog, $bahan);
        if ($proses === false) {
            $response = [
                'status' => 500,
                'message' => 'Data Gagal Disimpan',
                'error' => true
            ];
        } else {
            $response = [
                'status' => 200,
                'message' => 'Data Berhasil Disimpan',
                'error' => false
            ];
        }
        return json_encode($response);
    }

    public function editKatalog($id)
    {
        $data = [
            'row' => $this->query->getKatalog($id)->getRowArray(),
            'bahan' => $this->query->getBahan()->getResultArray(),
        ];
        return view('katalog/editKatalog', $data);
    }

    public function updateKatalog($id)
    {
        $katalog = $this->request->getVar('katalog');
        $bahan = $this->request->getVar('bahan');

        $proses = $this->query->updateKatalog($id, $katalog, $bahan);
        if ($proses === false) {
            $response = [
                'status' => 500,
                'message' => 'Data Gagal Disimpan',
                'error' => true
            ];
        } else {
            $response = [
                'status' => 200,
                'message' => 'Data Berhasil Disimpan',
                'error' => false
            ];
        }
        return json_encode($response);
    }

    public function deleteKatalog($id)
    {
        $proses = $this->query->deleteKatalog($id);
        if ($proses === false) {
            $response = [
                'status' => 500,
                'message' => 'Data Gagal Dihapus',
                'error' => true
            ];
        } else {
            $response = [
                'status' => 200,
                'message' => 'Data Berhasil Dihapus',
                'error' => false
            ];
        }
        return json_encode($response);
    }
}
