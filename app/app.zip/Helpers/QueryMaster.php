<?php

namespace App\Helpers;

class QueryMaster
{
    protected $db;
    protected $user_id;

    public function __construct()
    {
        $this->db = \Config\Database::connect();
        $this->user_id = session()->get('user_id');
    }

    public function getLogin($email)
    {
        $sql = "    SELECT  p.*
                    FROM    tb_pegawai p
                    WHERE   p.email = '$email'  ";
        return $this->db->query($sql);
    }

    public function getAccess($role)
    {
        $sql = "    SELECT      r.tb_pegawai, r.m_user_permission_inventori, u.url
                    FROM        m_role_permission_inventori r
                    LEFT JOIN   m_user_permission_inventori u ON u.id = r.m_user_permission_inventori
                    WHERE       r.tb_pegawai = '$role'  ";
        return $this->db->query($sql);
    }

    // public function getAccess($id)
    // {
    //     $sql = "    SELECT      p.url
    //                 FROM        m_role_permission_inventori_kimia rp
    //                 LEFT JOIN   m_permission_inventori_kimia p ON p.id = rp.m_permission_inventori_kimia
    //                 WHERE       rp.tb_pegawai = $id
    //                             AND p.is_active = 1
    //                             AND rp.is_delete = 0  ";
    //     return $this->db->query($sql);
    // }

    public function getBahan($id = false)
    {
        if ($id === false) {
            $sql = "    SELECT      i.*, s.nama AS nama_satuan
                        FROM        m_inventori_bahan_lab i
                        LEFT JOIN   m_inventori_bahan_lab_satuan s ON s.id = i.m_inventori_bahan_lab_satuan
                        WHERE       i.is_delete = 0
                        ORDER BY    i.kode ASC, i.nama ASC   ";
            return $this->db->query($sql);
        }
        $sql = "    SELECT  *
                    FROM    m_inventori_bahan_lab
                    WHERE   id = '$id'  ";
        return $this->db->query($sql);
    }

    public function getSatuan($id = false)
    {
        if ($id === false) {
            $sql = "    SELECT  *
                        FROM    m_inventori_bahan_lab_satuan
                        WHERE   is_delete = 0  ";
            return $this->db->query($sql);
        }
        $sql = "    SELECT  *
                    FROM    m_inventori_bahan_lab_satuan
                    WHERE   id = $id  ";
        return $this->db->query($sql);
    }

    public function getVendor($id = false)
    {
        if ($id === false) {
            $sql = "    SELECT  *
                        FROM    m_vendor
                        WHERE   is_delete = 0
                        ORDER BY nama ASC  ";
            return $this->db->query($sql);
        }
        $sql = "    SELECT  *
                    FROM    m_vendor
                    WHERE   id = $id  ";
        return $this->db->query($sql);
    }

    public function saveBahan($data)
    {
        $sql = "    INSERT INTO     m_inventori_bahan_lab
                    SET             kode            = '$data->kode',
                                    nama            = '$data->nama',
                                    alias           = '$data->alias',
                                    m_inventori_bahan_lab_satuan = '$data->satuan',
                                    gramasi         = '$data->gramasi',
                                    created_user    = '$this->user_id',
                                    created_date    = CURRENT_TIMESTAMP  ";
        return $this->db->query($sql);
    }

    public function updateBahan($id, $data)
    {
        $sql = "    UPDATE  m_inventori_bahan_lab
                    SET     kode            = '$data->kode',
                            nama            = '$data->nama',
                            alias           = '$data->alias',
                            m_inventori_bahan_lab_satuan = '$data->satuan',
                            gramasi         = '$data->gramasi',
                            updated_user    = '$this->user_id',
                            updated_date    = CURRENT_TIMESTAMP
                    WHERE   id = $id  ";
        return $this->db->query($sql);
    }

    public function deleteBahan($id)
    {
        $sql = "    UPDATE  m_inventori_bahan_lab
                    SET     is_delete = 1,
                            deleted_user = '$this->user_id',
                            deleted_date = CURRENT_TIMESTAMP
                    WHERE   id = $id  ";
        return $this->db->query($sql);
    }

    public function saveSatuan($nama)
    {
        $sql = "    INSERT INTO     m_inventori_bahan_lab_satuan
                    SET             nama         = '$nama',
                                    created_user = '$this->user_id',
                                    created_date = CURRENT_TIMESTAMP  ";
        return $this->db->query($sql);
    }

    public function updateSatuan($id, $nama)
    {
        $sql = "    UPDATE  m_inventori_bahan_lab_satuan
                    SET     nama         = '$nama',
                            updated_user = '$this->user_id',
                            updated_date = CURRENT_TIMESTAMP
                    WHERE   id = $id  ";
        return $this->db->query($sql);
    }

    public function deleteSatuan($id)
    {
        $sql = "    UPDATE  m_inventori_bahan_lab_satuan
                    SET     is_delete    = 1,
                            deleted_user = '$this->user_id',
                            deleted_date = CURRENT_TIMESTAMP
                    WHERE   id = $id  ";
        return $this->db->query($sql);
    }

    public function saveVendor($data)
    {
        $sql = "    INSERT INTO     m_vendor
                    SET             nama            = '$data->nama',
                                    alamat          = '$data->alamat',
                                    telp            = '$data->telp',
                                    pic_nama        = '$data->pic_nama',
                                    pic_telp        = '$data->pic_telp',
                                    created_user    = '$this->user_id',
                                    created_date    = CURRENT_TIMESTAMP  ";
        return $this->db->query($sql);
    }

    public function updateVendor($id, $data)
    {
        $sql = "    UPDATE  m_vendor
                    SET     nama            = '$data->nama',
                            alamat          = '$data->alamat',
                            telp            = '$data->telp',
                            pic_nama        = '$data->pic_nama',
                            pic_telp        = '$data->pic_telp',
                            updated_user    = '$this->user_id',
                            updated_date    = CURRENT_TIMESTAMP
                    WHERE   id = $id  ";
        return $this->db->query($sql);
    }

    public function deleteVendor($id)
    {
        $sql = "    UPDATE  m_vendor
                    SET     is_delete    = 1,
                            deleted_user = '$this->user_id',
                            deleted_date = CURRENT_TIMESTAMP
                    WHERE   id = $id  ";
        return $this->db->query($sql);
    }

    public function getKatalog($id = false)
    {
        if ($id === false) {
            $sql = "    SELECT      a.*, b.nama AS nama_bahan
                        FROM        m_inventori_bahan_lab_katalog a
                        LEFT JOIN   m_inventori_bahan_lab b ON b.id = a.m_inventori_bahan_lab
                        WHERE       a.is_delete = 0  ";
            return $this->db->query($sql);
        }
        $sql = "    SELECT  *
                    FROM    m_inventori_bahan_lab_katalog
                    WHERE   id = $id
                            AND is_delete = 0  ";
        return $this->db->query($sql);
    }

    public function savekatalog($katalog, $bahan)
    {
        $sql = "    INSERT INTO m_inventori_bahan_lab_katalog
                    SET         no_katalog = '$katalog',
                                m_inventori_bahan_lab = '$bahan'    ";
        return $this->db->query($sql);
    }

    public function updateKatalog($id, $katalog, $bahan)
    {
        $sql = "    UPDATE  m_inventori_bahan_lab_katalog
                    SET     no_katalog   = '$katalog',
                            m_inventori_bahan_lab = '$bahan',
                            updated_user = '$this->user_id',
                            updated_date = CURRENT_TIMESTAMP
                    WHERE   id = $id  ";
        return $this->db->query($sql);
    }

    public function deleteKatalog($id)
    {
        $sql = "    UPDATE  m_inventori_bahan_lab_katalog
                    SET     is_delete    = 1,
                            deleted_user = '$this->user_id',
                            deleted_date = CURRENT_TIMESTAMP
                    WHERE   id = $id  ";
        return $this->db->query($sql);
    }
}
