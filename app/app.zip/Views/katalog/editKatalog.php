<div class="modal fade" id="edit_katalog" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Ubah Katalog</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="overlay-wrapper" hidden>
                <div class="overlay">
                    <i class="fas fa-3x fa-sync-alt fa-spin"></i>
                </div>
            </div>
            <form action="" method="POST" id="form_edit_katalog">
                <?= csrf_field(); ?>
                <div class="modal-body">
                    <div class="card-body py-0">
                        <div class="form-group">
                            <label for="katalog">No. Katalog</label>
                            <input type="text" class="form-control" name="katalog" value="<?= $row['no_katalog']; ?>" autocomplete="off">
                        </div>
                        <div class="form-group">
                            <label for="bahan">Nama Bahan</label>
                            <select class="form-control select2-full" name="bahan" data-placeholder="-- Pilih Bahan --">
                                <option></option>
                                <?php foreach ($bahan as $value) { ?>
                                    <option value="<?= $value['id']; ?>" <?= ($value['id'] == $row['m_inventori_bahan_lab']) ? 'selected' : ''; ?>><?= $value['nama']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
                    <button type="button" id="btn_submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    $(function() {
        $('.select2-full').select2({
            dropdownParent: $('#edit_katalog'),
            theme: 'bootstrap4',
        });
    })

    $('#btn_submit').click(function() {
        $('.overlay-wrapper').attr('hidden', false);
        let data = $('#form_edit_katalog').serialize();
        let id = "<?= $row['id']; ?>";
        $.ajax({
            url: "katalog/updateKatalog/" + id,
            data: data,
            type: "POST",
            dataType: "JSON",
            success: function(response) {
                $('.overlay-wrapper').attr('hidden', true);
                if (response.error) {
                    errorAlert(response.message);
                } else {
                    successAlert(response.message);
                    $('#edit_katalog').modal('hide');
                    loadDataKatalog();
                }
            }
        })
    });
</script>