<?php
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=report-bahan_created-at-" . date('d-m-Y') . ".xls");
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Report Per Bahan</title>
</head>

<body>
    <h2>Report Per Bahan</h2>
    <table border="0">
        <tbody>
            <tr>
                <td>Tanggal</td>
                <td><?= date('d-m-Y', strtotime($filter_tglawal)); ?> s/d <?= date('d-m-Y', strtotime($filter_tglakhir)); ?></td>
            </tr>
            <tr>
                <td>Bahan</td>
                <td><?= $filter_bahan; ?></td>
            </tr>
            <tr>
                <table border="1">
                    <thead>
                        <tr>
                            <th align="center">No.</th>
                            <th align="center">Tanggal</th>
                            <th align="center">Total Masuk</th>
                            <th align="center">Total Keluar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($data_bahan as $value) { ?>
                            <tr>
                                <td align="center"><?= $no++; ?></td>
                                <td align="center"><?= date('d-m-Y', strtotime($value['tanggal'])); ?></td>
                                <td align="center"><?= ($value['total_masuk']) ? str_replace('.', ',', $value['total_masuk']) : 0; ?></td>
                                <td align="center"><?= ($value['total_keluar']) ? str_replace('.', ',', $value['total_keluar']) : 0; ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
        </tbody>
    </table>
</body>

</html>