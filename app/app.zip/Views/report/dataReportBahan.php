<table class="table table-hover table-bordered table-striped" id="data-table">
    <thead>
        <tr>
            <th class="text-center" width="1%">No.</th>
            <th class="text-center">Tanggal</th>
            <th class="text-center">Total Masuk</th>
            <th class="text-center">Total Keluar</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $no = 1;
        foreach ($data_bahan as $value) { ?>
            <tr>
                <td class="text-center"><?= $no++; ?></td>
                <td class="text-center"><?= date('d-m-Y', strtotime($value['tanggal'])); ?></td>
                <td class="text-center"><?php
                                        $total_masuk = $value['total_masuk'] * $value['gramasi'];
                                        if ($total_masuk > 999) {
                                            $str = $total_masuk;
                                            $dec = strlen(substr(strrchr($str, "."), 1));
                                            echo number_format($total_masuk, $dec, ',', '.');
                                        } else {
                                            echo str_replace('.', ',', $total_masuk);
                                        } ?></td>
                <td class="text-center"><?php if ($value['total_keluar'] > 999) {
                                            $str = $value['total_keluar'];
                                            $dec = strlen(substr(strrchr($str, "."), 1));
                                            echo number_format($value['total_keluar'], $dec, ',', '.');
                                        } else {
                                            echo str_replace('.', ',', $value['total_keluar']);
                                        }; ?></td>
            </tr>
        <?php } ?>
    </tbody>
</table>
<a href="<?= site_url(); ?>report/reportBahan/exportReportBahan?tglawal=<?= $filter_tglawal; ?>&tglakhir=<?= $filter_tglakhir; ?>&bahan=<?= $filter_bahan; ?>" class="btn btn-default">Export ke Excel</a>